package controllers;

import apimodels.Espacio;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileInputStream;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2018-01-10T20:06:05.857Z")

public class EspaciosApiControllerImp implements EspaciosApiControllerImpInterface {
    @Override
    public List<Espacio> espaciosGet() throws Exception {
        //Do your magic!!!
        return new ArrayList<Espacio>();
    }

}
