package controllers.ms_gestion_economica;

import services.GestionDeNominas_ApiControllerImpInterface;
import models.Nomina;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileInputStream;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2018-01-05T21:31:07.061Z")

public class GestionDeNominas_ApiControllerImp implements GestionDeNominas_ApiControllerImpInterface {
    @Override
    public void nominaPost( @NotNull @Pattern(regexp = "^([0-9]{8}|[XYZ]{1}[0-9]{7})[TRWAGMYFPDXBNJZSQVHLCKET]{1}$") @Size(min = 9, max = 9) String nif,  @NotNull String fecha) throws Exception {
        HttpPost post = new HttpPost("http://localhost:9000");
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("nif", nif));
        urlParameters.add(new BasicNameValuePair("fecha", fecha));
        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        return new DefaultHttpClient().execute(post);
        
    }

    @Override
    public List<Nomina> nominasNIFGet(String NIF) throws Exception {
        //Do your magic!!!
        return new ArrayList<Nomina>();
    }

}
