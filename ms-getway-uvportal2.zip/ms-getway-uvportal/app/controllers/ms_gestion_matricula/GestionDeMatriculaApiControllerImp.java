package controllers.ms_gestion_matricula;


import services.GestionDeMatriculaApiControllerImpInterface;
import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileInputStream;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2018-01-05T21:31:07.061Z")

public class GestionDeMatriculaApiControllerImp implements GestionDeMatriculaApiControllerImpInterface {
    @Override
    public Boolean reservaMatriculaGet( @NotNull Integer promocion,  @NotNull String alumno) throws Exception {
        //Do your magic!!!
        return new Boolean("");
    }

    @Override
    public void reservaMatriculaPut( @NotNull Integer promocion,  @NotNull String alumno) throws Exception {
        //Do your magic!!!
        
    }

}
