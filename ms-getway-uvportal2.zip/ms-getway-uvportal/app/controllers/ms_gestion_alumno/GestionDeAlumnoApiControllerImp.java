package controllers.ms_gestion_alumno;

import services.GestionDeAlumnoApiControllerImpInterface;
import models.Alumno;
import services.GestionDeAuthentificacionApiControllerImpInterface;
import java.util.ArrayList;
import java.util.List;
import javax.validation.constraints.*;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileInputStream;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2018-01-05T21:31:07.061Z")

public class GestionDeAlumnoApiControllerImp implements GestionDeAlumnoApiControllerImpInterface {
   
 
    @Override
    public HttpResponse altaAlumnoPost(Alumno alumno) throws Exception {
       HttpPost post = new HttpPost("http://localhost:9000");
       List<NameValuePair> urlParameters = new ArrayList<>();
       urlParameters.add(new BasicNameValuePair("Alumno", alumno));
        post.setEntity(new UrlEncodedFormEntity(urlParameters));
        return new DefaultHttpClient().execute(post);
        
    }

    @Override
    public HttpResponse alumnoByNIFNIFDelete(@NotNull @Pattern(regexp = "^([0-9]{8}|[XYZ]{1}[0-9]{7})[TRWAGMYFPDXBNJZSQVHLCKET]{1}$") @Size(min = 9, max = 9) String NIF) throws Exception {
       
    }

    @Override
    public HttpResponse alumnoByNIFNIFGet(@NotNull @Pattern(regexp = "^([0-9]{8}|[XYZ]{1}[0-9]{7})[TRWAGMYFPDXBNJZSQVHLCKET]{1}$") @Size(min = 9, max = 9) String NIF) throws Exception {
         HttpGet get= new HttGet("http://localhost:9000");
        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("NIF", NIF));
        get.setRequestProperty(urlParameters);
        return new DefaultHttpClient().execute(get).getResponseCode();
        
    }

    @Override
    public void alumnoByNIFNIFPut(String NIF, Alumno alumno) throws Exception {
        //Do your magic!!!
        
    }

}
