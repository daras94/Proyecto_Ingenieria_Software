package services;

import models.Espacio;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import javax.validation.constraints.*;

public interface GestionDeEspacios_ApiControllerImpInterface {
    List<Espacio> espaciosGet() throws Exception;

}
